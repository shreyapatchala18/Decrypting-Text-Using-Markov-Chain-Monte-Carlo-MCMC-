from mcmc_decryptor import generate_encryption_key
from mcmc_decryptor import encrypt_text, apply_decryption, preprocess_text

# Test cases with spaces and capital letters
test_cases = [
    "The Quick Brown Fox Jumps Over The Lazy Dog",
    "A Quick Brown Fox",
    "The Quick Brown Fox Jumps Over The Lazy Dog Again",
    "AAAAAAAAAAAAAAAAAAAAAA",
]

# Reference text for frequency analysis
reference_text = preprocess_text("The quick brown fox jumps over the lazy dog")

# Encryption key generation
encryption_key = generate_encryption_key()

# Run all test cases
for i, original_text in enumerate(test_cases, start=1):
    plaintext = preprocess_text(original_text)  # Preprocess the text
    encrypted_text = encrypt_text(plaintext, encryption_key)
    decryption_key = {v: k for k, v in encryption_key.items()}
    decrypted_text = apply_decryption(decryption_key, encrypted_text)

    print(f"Test Case {i}:")
    print(f"Original Text: {original_text}")
    print(f"Preprocessed Plaintext: {plaintext}")
    print(f"Encrypted Text: {encrypted_text}")
    print(f"Decrypted Text: {decrypted_text}")
    print(f"Expected Decryption: {plaintext}")
    print(f"Pass: {decrypted_text == plaintext}")
    print("-" * 40)